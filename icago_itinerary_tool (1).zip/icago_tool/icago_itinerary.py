#!/usr/bin/env python3
"""
icago_itinerary.py — ICAGO Itinerary Converter
================================================
Chuyển đổi file PDF lịch trình (từ GDS/Amadeus) sang định dạng ICAGO chuẩn.

✅ Chạy trên Windows / macOS / Linux — KHÔNG cần cài pdftotext.

Cài đặt (chạy một lần):
  pip install reportlab pillow pdfplumber

Cách dùng:
  python icago_itinerary.py Itinerary.pdf
  python icago_itinerary.py Itinerary.pdf output.pdf
  python icago_itinerary.py Itinerary.pdf -v
  python icago_itinerary.py --help
"""

import argparse
import os
import re
import sys

# ── Kiểm tra thư viện ─────────────────────────────────────────────────────────
try:
    import pdfplumber
except ImportError:
    sys.exit("❌ Thiếu pdfplumber. Chạy:  pip install pdfplumber")

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Spacer, Image as RLImage, Flowable
except ImportError:
    sys.exit("❌ Thiếu reportlab. Chạy:  pip install reportlab")

try:
    from PIL import Image as PILImage
except ImportError:
    sys.exit("❌ Thiếu pillow. Chạy:  pip install pillow")

# ── Đường dẫn ảnh mặc định (cùng thư mục script) ─────────────────────────────
_SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
DEFAULT_LOGO = os.path.join(_SCRIPT_DIR, "icago_logo.png")
DEFAULT_LUUY = os.path.join(_SCRIPT_DIR, "icago_luuy.png")

# ── Layout PDF ─────────────────────────────────────────────────────────────────
PAGE_W, PAGE_H = letter
MARGIN_L  = 50
MARGIN_R  = 50
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R

FONT_MONO = "Courier"
FONT_BOLD = "Courier-Bold"
FONT_SIZE = 8.5
LINE_H    = 12


# ══════════════════════════════════════════════════════════════════════════════
# 1. Trích xuất văn bản giữ layout cột (dùng pdfplumber, không cần pdftotext)
# ══════════════════════════════════════════════════════════════════════════════

def extract_pages(pdf_path, verbose=False):
    """
    Dùng pdfplumber layout=True — tương đương pdftotext -layout.
    Giữ nguyên khoảng trắng giữa 2 cột trong header.
    Trả về list[str], mỗi phần tử là văn bản một trang.
    """
    pages = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text(
                layout=True,
                x_density=7.25,
                y_density=13,
            ) or ""
            pages.append(text)
    if verbose:
        print(f"  [extract] {len(pages)} trang trong '{pdf_path}'")
    return pages


# ══════════════════════════════════════════════════════════════════════════════
# 2. Phân tích header trang 1
# ══════════════════════════════════════════════════════════════════════════════

def parse_header(header_lines, verbose=False):
    """
    Header gốc có 2 cột nối trên cùng dòng qua khoảng trắng lớn:
      '          TUONG LAI VIET (BSP)              BOOKING REF: E6ZDTU'
      '          HO CHI MINH CITY                  HUYNH/THI TAM'

    Chiến lược:
      - rstrip() loại bỏ khoảng trắng cuối dòng
      - Bỏ qua indent đầu dòng, tìm gap 4+ spaces đầu tiên trong nội dung
      - Lấy phần bên PHẢI gap đó
      - Giữ: BOOKING REF, tên hành khách (HO/TEN)
      - Bỏ: DATE và địa chỉ đại lý
    """
    kept = []
    for line in header_lines:
        stripped = line.rstrip()
        if not stripped.strip():
            continue

        # Bỏ qua indent đầu dòng
        m_indent = re.match(r'^\s+', stripped)
        content_start = m_indent.end() if m_indent else 0
        rest = stripped[content_start:]

        # Tìm gap đầu tiên sau nội dung (ranh giới cột trái/phải)
        m_gap = re.search(r'\s{4,}', rest)
        if not m_gap:
            continue  # dòng đơn cột → bỏ (địa chỉ)

        right = rest[m_gap.end():].strip()
        if not right:
            continue

        if re.match(r'^DATE\s*:', right, re.IGNORECASE):
            if verbose:
                print(f"  [header] bỏ DATE   : {repr(right)}")
            continue

        if re.match(r'^BOOKING\s+REF\s*:', right, re.IGNORECASE):
            kept.append(right)
            if verbose:
                print(f"  [header] giữ       : {repr(right)}")
            continue

        if re.match(r'^[A-Z\-]+/[A-Z]', right):
            kept.append(right)
            if verbose:
                print(f"  [header] hành khách: {repr(right)}")

    return kept


# ══════════════════════════════════════════════════════════════════════════════
# 3. Xóa các dòng không cần trong body
# ══════════════════════════════════════════════════════════════════════════════

_DELETE_PATTERNS = [
    r"FLIGHT\(S\)\s+CALCULATED\s+AVERAGE\s+CO2",
    r"SOURCE:\s*ICAO\s+CARBON\s+EMISSIONS",
    r"https?://www\.icao\.int",
    r"HTTPS?://BAGS\.AMADEUS\.COM",
    r"CHECK\s+YOUR\s+TRIP\s+ONLINE",
    r"CLICK\s+HERE",
    r"Data\s+Protection\s+Notice\s*:",
    r"with\s+the\s+applicable\s+carrier",
    r"a\s+reservation\s+system\s+provider",
    r"available\s+at\s+or\s+from\s+the\s+carrier",
    r"documentation,\s+which\s+applies\s+to\s+your\s+booking",
    r"your\s+personal\s+data\s+is\s+collected",
    r"\(applicable\s+for\s+interline\s+carriage\)",
]
_DELETE_RE = [re.compile(p, re.IGNORECASE) for p in _DELETE_PATTERNS]


def _should_delete(line):
    s = line.strip()
    return any(rx.search(s) for rx in _DELETE_RE)


def clean_body(lines, verbose=False):
    result = []
    skip_rest = False

    for line in lines:
        s = line.strip()
        if re.match(r"Data\s+Protection\s+Notice\s*:", s, re.IGNORECASE):
            skip_rest = True
            if verbose:
                print(f"  [body] bắt đầu bỏ từ: {repr(s[:60])}")
        if skip_rest:
            continue
        if _should_delete(line):
            if verbose:
                print(f"  [body] xóa: {repr(s[:80])}")
            continue
        result.append(line)

    while result and not result[-1].strip():
        result.pop()
    return result


# ══════════════════════════════════════════════════════════════════════════════
# 4. Xử lý các trang
# ══════════════════════════════════════════════════════════════════════════════

def process_pages(pages, verbose=False):
    """
    Trang 1 : header + body.
    Trang 2+: bỏ (legalese / Amadeus junk).
    """
    header_lines = []
    body_lines   = []

    for idx, page_text in enumerate(pages):
        lines = page_text.split("\n")

        if idx == 0:
            # Tìm dòng FLIGHT đầu tiên (không phải FLIGHT BOOKING REF)
            flight_idx = next(
                (i for i, l in enumerate(lines)
                 if re.search(r'FLIGHT\s+', l)
                 and not re.search(r'FLIGHT\s+BOOKING', l)),
                len(lines),
            )
            header_lines = parse_header(lines[:flight_idx], verbose)
            body_lines   = clean_body(lines[flight_idx:], verbose)
            if verbose:
                print(f"  [page 1] header={len(header_lines)}, body={len(body_lines)} dòng")
        else:
            if verbose:
                print(f"  [page {idx+1}] bỏ qua")

    return header_lines, body_lines


# ══════════════════════════════════════════════════════════════════════════════
# 5. Style dòng — in đậm
# ══════════════════════════════════════════════════════════════════════════════

_BOLD_RE = [
    re.compile(r"^\s*FLIGHT\s+(?!BOOKING)", re.IGNORECASE),
    re.compile(r"^\s*DEPARTURE\s*:",        re.IGNORECASE),
    re.compile(r"^\s*ARRIVAL\s*:",          re.IGNORECASE),
    re.compile(r"^\s*FLIGHT\s+TICKET\(S\)", re.IGNORECASE),
]

def is_bold(line):
    return any(rx.match(line) for rx in _BOLD_RE)


# ══════════════════════════════════════════════════════════════════════════════
# 6. ReportLab Flowable — dòng monospace
# ══════════════════════════════════════════════════════════════════════════════

class MonoLine(Flowable):
    def __init__(self, text, bold=False):
        super().__init__()
        self.text   = text
        self.bold   = bold
        self.width  = CONTENT_W
        self.height = LINE_H

    def draw(self):
        self.canv.setFont(FONT_BOLD if self.bold else FONT_MONO, FONT_SIZE)
        self.canv.drawString(0, 2, self.text)


# ══════════════════════════════════════════════════════════════════════════════
# 7. Tạo PDF
# ══════════════════════════════════════════════════════════════════════════════

def _scaled_image(path, max_w):
    img = PILImage.open(path)
    w, h = img.size
    return RLImage(path, width=max_w, height=max_w * h / w)


def build_pdf(header_lines, body_lines, output_path, logo_path, luuy_path, verbose=False):
    story = []

    if logo_path and os.path.isfile(logo_path):
        story.append(_scaled_image(logo_path, CONTENT_W))
        story.append(Spacer(1, 8))
        if verbose:
            print(f"  [build] logo  : {logo_path}")
    else:
        print(f"  ⚠️  Không tìm thấy logo: {logo_path}")

    for line in header_lines:
        story.append(MonoLine(line, bold=False))
    story.append(Spacer(1, 6))

    for line in body_lines:
        story.append(MonoLine(line, bold=is_bold(line)))

    story.append(Spacer(1, 14))
    if luuy_path and os.path.isfile(luuy_path):
        story.append(_scaled_image(luuy_path, CONTENT_W))
        if verbose:
            print(f"  [build] lưu ý : {luuy_path}")
    else:
        print(f"  ⚠️  Không tìm thấy ảnh Lưu ý: {luuy_path}")

    SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=MARGIN_L,
        rightMargin=MARGIN_R,
        topMargin=30,
        bottomMargin=30,
    ).build(story)


# ══════════════════════════════════════════════════════════════════════════════
# 8. CLI
# ══════════════════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(
        prog="icago_itinerary",
        description="Chuyển đổi lịch trình GDS/Amadeus sang định dạng ICAGO PDF.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ví dụ:
  python icago_itinerary.py Itinerary.pdf
  python icago_itinerary.py Itinerary.pdf KhachHang.pdf
  python icago_itinerary.py Itinerary.pdf -o KhachHang.pdf --logo logo.png --luuy luuy.png
  python icago_itinerary.py Itinerary.pdf -v

Ảnh mặc định (đặt cùng thư mục script):
  icago_logo.png  →  logo ICAGO đầu trang
  icago_luuy.png  →  ảnh Lưu ý cuối trang
        """,
    )
    p.add_argument("input",  help="File PDF đầu vào")
    p.add_argument("output", nargs="?", default=None,
                   help="File PDF đầu ra (mặc định: <input>_ICAGO.pdf)")
    p.add_argument("-o", "--output-file", dest="output_file",
                   default=None, metavar="PATH")
    p.add_argument("--logo", default=DEFAULT_LOGO, metavar="FILE",
                   help="Ảnh logo ICAGO  (mặc định: icago_logo.png)")
    p.add_argument("--luuy", default=DEFAULT_LUUY, metavar="FILE",
                   help="Ảnh Lưu ý       (mặc định: icago_luuy.png)")
    p.add_argument("-v", "--verbose", action="store_true",
                   help="Hiển thị chi tiết xử lý")
    return p.parse_args()


def main():
    args = parse_args()
    output = args.output_file or args.output or \
             os.path.splitext(args.input)[0] + "_ICAGO.pdf"

    if not os.path.isfile(args.input):
        sys.exit(f"❌ Không tìm thấy file: {args.input}")

    print(f"📄 Input  : {args.input}")
    print(f"📝 Output : {output}")
    print(f"🖼️  Logo   : {args.logo}")
    print(f"🖼️  Lưu ý : {args.luuy}")
    if args.verbose:
        print("🔍 Verbose ON\n")

    pages = extract_pages(args.input, args.verbose)
    header, body = process_pages(pages, args.verbose)

    if args.verbose:
        print(f"\n📋 Header ({len(header)} dòng):")
        for l in header: print(f"    {l}")
        print(f"\n📋 Body ({len(body)} dòng) — 5 dòng đầu:")
        for l in body[:5]: print(f"    {repr(l)}")
        print()

    build_pdf(header, body, output, args.logo, args.luuy, args.verbose)

    print(f"✅ Hoàn thành! → {output}  ({os.path.getsize(output)//1024} KB)")


if __name__ == "__main__":
    main()
