# ICAGO Itinerary Converter

Công cụ chuyển đổi lịch trình GDS/Amadeus PDF sang định dạng ICAGO chuẩn.
✅ Chạy trên **Windows / macOS / Linux** — không cần cài pdftotext.

## Cài đặt (chạy một lần)

```
pip install reportlab pillow pdfplumber
```

## Cấu trúc thư mục

```
icago_tool/
├── icago_itinerary.py   ← Script chính
├── icago_logo.png       ← Logo ICAGO đầu trang  (thay bằng file của bạn)
├── icago_luuy.png       ← Ảnh Lưu ý cuối trang  (thay bằng file của bạn)
└── README.md
```

## Cách dùng

```bash
# Đơn giản nhất — output tự động: Itinerary_ICAGO.pdf
python icago_itinerary.py Itinerary.pdf

# Đặt tên output tùy ý
python icago_itinerary.py Itinerary.pdf NGUYEN_VAN_A.pdf

# Dùng ảnh tùy chỉnh
python icago_itinerary.py Itinerary.pdf -o output.pdf --logo my_logo.png --luuy my_luuy.png

# Xem chi tiết từng bước xử lý
python icago_itinerary.py Itinerary.pdf -v

# Xem tất cả tùy chọn
python icago_itinerary.py --help
```

## Những gì tool tự động làm

| Thay đổi | Chi tiết |
|----------|----------|
| Xóa header trái | Địa chỉ đại lý, điện thoại, email |
| Giữ header phải | BOOKING REF, tên hành khách |
| Xóa dòng DATE | DATE: 10 APRIL 2026 |
| In đậm | FLIGHT, DEPARTURE, ARRIVAL, FLIGHT TICKET(S) |
| Xóa CO2 block | FLIGHT(S) CALCULATED AVERAGE CO2... |
| Xóa junk | Amadeus URL, CHECK YOUR TRIP ONLINE, CLICK HERE |
| Xóa legalese | Data Protection Notice (toàn bộ) |
| Thêm logo | icago_logo.png — đầu trang |
| Thêm Lưu ý | icago_luuy.png — cuối trang |

## Thay ảnh mặc định

Đặt file ảnh của bạn cùng thư mục script, đúng tên:
- `icago_logo.png` → tự nhận làm logo
- `icago_luuy.png` → tự nhận làm ảnh Lưu ý

Hoặc dùng tham số `--logo` / `--luuy` chỉ đường dẫn bất kỳ.
